"require"in window&&require("discourse/lib/theme-settings-store").registerSettings(22,{external_link_origins:"https://www.spiceworks.com|https://spiceworks.com|https://www.swzd.com|https://swzd.com|https://www.aberdeen.com/|https://aberdeen.com/",constant_utm_params:'[{"utm_param_key":"utm_source","utm_param_value":"community"}]'}),"define"in window&&define("discourse/theme-22/discourse/api-initializers/utm-tracking",["exports","discourse/lib/api"],(function(e,t){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
const n=require("discourse/lib/theme-settings-store").getObjectForTheme(22)
e.default=(0,t.apiInitializer)("0.11.1",(e=>{if(!n.external_link_origins)return
const t=JSON.parse(n.constant_utm_params).reduce(((e,t)=>(e[t.utm_param_key]=()=>t.utm_param_value,e)),{})
window.UTMTracking={trackingOrigins:n.external_link_origins.split("|"),utmParams:{...t,utm_content:e=>encodeURIComponent(e?.trim()??"unknown"),utm_page:()=>encodeURIComponent(document.title??"unknown")},getAppendedUtmParamsUrl:e=>{let{href:t,textContent:n}=e
try{const{utmParams:e}=window.UTMTracking,r=new URL(t),i=new URLSearchParams(r.search)
return Object.keys(e).forEach((t=>{i.get(t)||i.append(t,e[t](n))})),r.search=i.toString(),r.toString()}catch(e){return console.error(e),t}},appendToPageLinks:()=>{const{trackingOrigins:e,getAppendedUtmParamsUrl:t}=window.UTMTracking
document.body.querySelectorAll("a").forEach((n=>e.forEach((e=>{0===n.href.indexOf(e)&&(n.href=t(n))}))))}},e.onPageChange(window.UTMTracking.appendToPageLinks)}))}))

//# sourceMappingURL=0d4c2cc849948eff5ae579cddf102642945607e3.map?__ws=community.spiceworks.com
