"define"in window&&define("discourse/theme-27/discourse/pre-initializers/theme-27-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-27-translations",initialize(){const e={en:{footer:{connect:"Connect",rsesources:"Resources",tech_marketers:"For Tech Marketers",spiceworks:"Spiceworks",need_help:"Need Help?",copyright:"Copyright © 2006 — 2024 Spiceworks Inc."}}}
for(let t in e){let s=I18n.translations
for(let e of[t,"js","theme_translations"])s=s[e]=s[e]||{}
s[27]=e[t]}}}}))

//# sourceMappingURL=044cc90eb8e37dfe58acff4c6f25fea5217aeb16.map?__ws=community.spiceworks.com
