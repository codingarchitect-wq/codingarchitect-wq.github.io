"define"in window&&define("discourse/theme-18/discourse/api-initializers/modifications_for_google_analytics",["exports","discourse/lib/api","discourse-common/lib/get-owner"],(function(e,i,o){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
require("discourse/lib/theme-settings-store").getObjectForTheme(18)
e.default=(0,i.apiInitializer)("0.11.1",(e=>{const i=(0,o.getOwner)(void 0).lookup("service:current-user"),r=window.dataLayer?.find((e=>e.userId))
r&&(r.userId=i?.external_id)}))}))

//# sourceMappingURL=6b300492bcdbdabfe85b4dc451fb03465759a7c7.map?__ws=community.spiceworks.com
