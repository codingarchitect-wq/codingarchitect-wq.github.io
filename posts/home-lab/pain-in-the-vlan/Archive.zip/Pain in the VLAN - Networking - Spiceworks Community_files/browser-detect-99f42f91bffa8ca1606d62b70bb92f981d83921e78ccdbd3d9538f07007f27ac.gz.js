(function(){if(window.WeakMap&&window.Promise&&"undefined"!=typeof globalThis&&String.prototype.replaceAll&&CSS.supports&&CSS.supports("aspect-ratio: 1")){try{(new WeakMap).has(0)}catch(r){window.unsupportedBrowser=!0}var e=window.navigator.userAgent.match(/Firefox\/([0-9]+)\./),o=e?parseInt(e[1],10):null
o&&o<89&&(window.unsupportedBrowser=!0)}else window.unsupportedBrowser=!0})()

//# sourceMappingURL=browser-detect-d6593973a5e2ecaffb3cfe4e95c12f3a269ea4b4a7e92490d159a5bd841ec570.map
//!
;
