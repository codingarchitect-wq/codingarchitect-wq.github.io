"define"in window&&define("discourse/theme-23/discourse/pre-initializers/theme-23-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-23-translations",initialize(){const e={en:{top_contributors:{heading:"Top contributors",view_all:"View all"},popular_tags:{heading:"Popular tags",view_all:"View all"},recent_replies:{heading:"Recent replies"},subcategory_list:{heading:"Subcategories"},top_topics:{heading:"Top topics"},category_list:{heading:"Categories"},upcoming_events:{heading:"Upcoming Events"},hot_topics:{heading:"Hot posts today :sw_fire:"}}}
for(let t in e){let i=I18n.translations
for(let e of[t,"js","theme_translations"])i=i[e]=i[e]||{}
i[23]=e[t]}}}}))

//# sourceMappingURL=7e8d0f9248385f66e9e86f8ad0b145969c68454c.map?__ws=community.spiceworks.com
