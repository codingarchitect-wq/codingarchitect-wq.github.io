document.addEventListener("discourse-booted",(e=>{performance.mark("discourse-booted")
const t=e.detail
require(`${t.modulePrefix}/app`).default.create(t).start()})),function(){if(window.unsupportedBrowser)throw"Unsupported browser detected"
require("ember")
let e=document.querySelector('meta[name="discourse/config/environment"]')
const t=JSON.parse(decodeURIComponent(e.getAttribute("content"))),o=new CustomEvent("discourse-booted",{detail:t})
document.dispatchEvent(o)}()

//# sourceMappingURL=start-discourse-5d7f503971ee51084b839dabaf96da17c03351df51736ce06fb063b64e816149.map
//!
;
