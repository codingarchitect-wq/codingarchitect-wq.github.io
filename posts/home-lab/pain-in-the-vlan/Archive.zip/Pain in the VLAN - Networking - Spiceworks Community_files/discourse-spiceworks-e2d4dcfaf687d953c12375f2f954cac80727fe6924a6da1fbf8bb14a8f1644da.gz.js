define("discourse/plugins/discourse-spiceworks/discourse/initializers/discourse-spiceworks",["exports","discourse/lib/plugin-api","discourse/lib/preload-store","discourse/lib/utilities"],(function(e,i,t,s){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"discourse-spiceworks",initialize(e){const r=e.lookup("service:current-user");(0,i.withPluginApi)("0.8.32",(e=>{r&&function(e){e.addNavigationBarItem({name:"myfeed",href:"/",before:"latest",customFilter:(e,i)=>!e&&!i.tagId})}(e),function(e){e.addNavigationBarItem({name:"featured",href:"/featured",before:"latest",customFilter:(e,i)=>!e&&!i.tagId})}(e),(0,s.setDefaultHomepage)(r?"myfeed":"featured"),t.default.remove("topic_list")}))}}}))

//# sourceMappingURL=discourse-spiceworks-249d10e3fb2631eb8443053ac6827b10c506a7ec9f9ecbeefab35f0419789050.map
//!

;
