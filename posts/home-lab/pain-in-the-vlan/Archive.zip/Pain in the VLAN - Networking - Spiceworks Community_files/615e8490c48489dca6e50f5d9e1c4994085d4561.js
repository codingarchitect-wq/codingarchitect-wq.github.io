"define"in window&&define("discourse/theme-25/discourse/pre-initializers/theme-25-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-25-translations",initialize(){const e={en:{}}
for(let t in e){let i=I18n.translations
for(let e of[t,"js","theme_translations"])i=i[e]=i[e]||{}
i[25]=e[t]}}}}))

//# sourceMappingURL=615e8490c48489dca6e50f5d9e1c4994085d4561.map?__ws=community.spiceworks.com
