(function(){const t=document.getElementById("data-google-tag-manager"),e=JSON.parse(t.dataset.dataLayer),a=t.dataset.nonce
window.dataLayer=[e],function(t,e,n,o,r){t[o]=t[o]||[],t[o].push({"gtm.start":(new Date).getTime(),event:"gtm.js"})
var s=e.getElementsByTagName(n)[0],d=e.createElement(n)
d.async=!0,d.src="https://www.googletagmanager.com/gtm.js?id="+r,d.setAttribute("nonce",a),s.parentNode.insertBefore(d,s)}(window,document,"script","dataLayer",t.dataset.containerId)})()

//# sourceMappingURL=google-tag-manager-28fec92fc63ed5152565c43f5342c098a1f3f3e9def1124373a0481b4abd4cab.map
//!
;
