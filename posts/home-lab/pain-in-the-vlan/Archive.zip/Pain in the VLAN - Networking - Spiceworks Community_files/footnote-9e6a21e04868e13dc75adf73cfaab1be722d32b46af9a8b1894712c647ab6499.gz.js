define("discourse/plugins/footnote/initializers/inline-footnotes",["exports","@popperjs/core","discourse/lib/plugin-api","discourse-common/lib/icon-library"],(function(t,e,o,n){"use strict"
let i
function r(t){i?.destroy()
const o=document.getElementById("footnote-tooltip")
if(o?.removeAttribute("data-show"),!t.target.classList.contains("expand-footnote"))return
t.preventDefault(),t.stopPropagation()
const n=t.target,r=n.closest(".cooked"),s=n.dataset.footnoteId,l=o.querySelector(".footnote-tooltip-content")
let d=r.querySelector(s)
l.innerHTML=d.innerHTML,o.dataset.show="",i?.destroy(),i=(0,e.createPopper)(n,o,{modifiers:[{name:"arrow",options:{element:o.querySelector("#arrow")}},{name:"preventOverflow",options:{altAxis:!0,padding:5}},{name:"offset",options:{offset:[0,12]}}]})}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
t.default={name:"inline-footnotes",initialize(t){t.lookup("service:site-settings").display_footnotes_inline&&(document.documentElement.append(function(){let t='\n    <div id="footnote-tooltip" role="tooltip">\n      <div class="footnote-tooltip-content"></div>\n      <div id="arrow" data-popper-arrow></div>\n    </div>\n  ',e=document.createElement("template")
return t=t.trim(),e.innerHTML=t,e.content.firstChild}()),window.addEventListener("click",r),(0,o.withPluginApi)("0.8.9",(t=>{t.decorateCookedElement((t=>function(t){const e=t.querySelectorAll("sup.footnote-ref")
e.forEach((t=>{const e=t.querySelector("a")
if(!e)return
const o=document.createElement("a")
o.classList.add("expand-footnote"),o.innerHTML=(0,n.iconHTML)("ellipsis-h"),o.href="",o.role="button",o.dataset.footnoteId=e.getAttribute("href"),t.after(o)})),e.length&&t.classList.add("inline-footnotes")}(t)),{onlyStream:!0,id:"inline-footnotes"}),t.onPageChange((()=>{document.getElementById("footnote-tooltip")?.removeAttribute("data-show")}))})))},teardown(){i?.destroy(),window.removeEventListener("click",r),document.getElementById("footnote-tooltip")?.remove()}}})),define("discourse/plugins/footnote/lib/discourse-markdown/footnotes",["exports"],(function(t){"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.setup=function(t){t.registerOptions(((t,e)=>{t.features.footnotes=window.markdownitFootnote&&!!e.enable_markdown_footnotes})),t.allowList(["ol.footnotes-list","hr.footnotes-sep","li.footnote-item","a.footnote-backref","sup.footnote-ref"]),t.allowList({custom(t,e,o){if(("a"===t||"li"===t)&&"id"===e)return!!o.match(/^fn(ref)?\d+$/)}}),window.markdownitFootnote&&t.registerPlugin(window.markdownitFootnote)}}))

//# sourceMappingURL=footnote-38ad4ddd96d53000e5606fa3bb10d539d237aa5d1367b32cfe2e7cf976c8b0a1.map
//!

;
