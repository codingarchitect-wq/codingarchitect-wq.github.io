"define"in window&&define("discourse/theme-14/discourse/pre-initializers/theme-14-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-14-translations",initialize(){const e={en:{footer:{copyright:"Copyright © 2006 — 2024 Spiceworks Inc."},featured_topics:{title:"Featured posts",view_all:"View all featured posts"},hot_topics:{heading:"Hot posts today :sw_fire:"},composer:{spiceworks_step:{label:"Add how-to step",placeholder_title:"### Step N: Step title here",placeholder_content:"Write the details of this step here."}}}}
for(let t in e){let i=I18n.translations
for(let e of[t,"js","theme_translations"])i=i[e]=i[e]||{}
i[14]=e[t]}}}}))

//# sourceMappingURL=c89f68e5c310086539c3d9a4b01ef80abca780e0.map?__ws=community.spiceworks.com
