var TopicListComponent=require("discourse/components/topic-list").default
TopicListComponent.reopen({showLikes:!0})

//# sourceMappingURL=ab300a6bd15506fd19dbe994a40ff8f81a938cae.map?__ws=community.spiceworks.com
