"define"in window&&define("discourse/theme-29/discourse/initializers/theme-field-532-common-html-script-1",["exports","discourse/lib/plugin-api"],(function(e,i){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
require("discourse/lib/theme-settings-store").getObjectForTheme(29)
e.default={name:"theme-field-532-common-html-script-1",after:"inject-objects",initialize(){(0,i.withPluginApi)("1.4.0",(e=>{e.onPageChange(((i,t)=>{let o={id:e.getCurrentUser()?e.getCurrentUser().id:null,external_id:e.getCurrentUser()?e.getCurrentUser().external_id:null}
window.CURRENT_USER=JSON.stringify(o)
const r=Discourse.__container__,d=Discourse._router.currentRoute,n=r.lookup("controller:topic")
let s={}
if(null!=n.get("model.id")&&(s.topic_id=n.get("model.id")),"discovery.category"==d?.name&&"Vendors"==d?.attributes?.category?.parentCategory?.name&&(s.vendorpage_id=d.attributes.category.id),window.ADDITIONAL_INFO=s,window.zd&&window.zd.core&&window.zd.core.utilities)window.zd.core.pageData.pageViewId=window.zd.core.utilities.generateUUID(),window.zd.core.pageData.cmsPageId=window.zd.core.utilities.getCMSPageId(),window.zd.core.pageData.local_uid=window.zd.core.utilities.getLocalUId(),window.zd.core.config.isFreshUser=window.zd.core.utilities.isFreshUser(),window.zd.core.pageData.url=window.window.location.href,window.zd.core.utilities.spaPageViewSignal()
else{var a=window.document.createElement("script")
a.src="https://cdn.static.zdbb.net/js/z0WVjCBSEeGLoxIxOQVEwQ.min.js",a.type="text/javascript",a.async=1,document.head.appendChild(a)}}))}))}}}))

//# sourceMappingURL=83031b19a472c450c8acdd48bb2344c7ed36e1aa.map?__ws=community.spiceworks.com
