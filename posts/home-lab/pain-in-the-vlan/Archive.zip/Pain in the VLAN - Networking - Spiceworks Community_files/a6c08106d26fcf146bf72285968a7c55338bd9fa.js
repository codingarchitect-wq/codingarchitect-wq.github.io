"define"in window&&define("discourse/theme-18/discourse/pre-initializers/theme-18-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-18-translations",initialize(){const e={en:{}}
for(let t in e){let i=I18n.translations
for(let e of[t,"js","theme_translations"])i=i[e]=i[e]||{}
i[18]=e[t]}}}}))

//# sourceMappingURL=a6c08106d26fcf146bf72285968a7c55338bd9fa.map?__ws=community.spiceworks.com
