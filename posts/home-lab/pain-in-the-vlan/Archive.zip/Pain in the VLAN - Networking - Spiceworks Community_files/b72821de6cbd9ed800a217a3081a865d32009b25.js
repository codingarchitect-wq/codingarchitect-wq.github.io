"define"in window&&define("discourse/theme-7/discourse/pre-initializers/theme-7-translations",["exports"],(function(e){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0
e.default={name:"theme-7-translations",initialize(){const e={en:{}}
for(let t in e){let i=I18n.translations
for(let e of[t,"js","theme_translations"])i=i[e]=i[e]||{}
i[7]=e[t]}}}}))

//# sourceMappingURL=b72821de6cbd9ed800a217a3081a865d32009b25.map?__ws=community.spiceworks.com
